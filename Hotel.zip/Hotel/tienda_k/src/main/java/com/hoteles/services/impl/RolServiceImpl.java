package com.hoteles.services.impl;

import com.hoteles.dao.RolDao;
import com.hoteles.domain.Rol;
import com.hoteles.services.RolService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RolServiceImpl 
        implements RolService {

    @Autowired
    private RolDao rolDao;
    
    @Override
    @Transactional(readOnly=true)
    public List<Rol> getRoles() {
        var lista = rolDao.findAll();        
               
        return lista;
    }

    @Override
    @Transactional(readOnly=true)
    public Rol getRol(Rol rol) {
        return rolDao.findById(rol.getIdRol()).orElse(null);
    }

    @Override
    @Transactional
    public void save(Rol rol) {
        rolDao.save(rol);
    }

    @Override
    @Transactional
    public void delete(Rol rol) {
        rolDao.delete(rol);
    }
}