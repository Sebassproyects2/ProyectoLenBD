package com.hoteles.dao;

import com.hoteles.domain.Ruta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RutaDao extends JpaRepository<Ruta, Long> {

}